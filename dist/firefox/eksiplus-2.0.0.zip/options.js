function saveOptions(e) {
  chrome.storage.local.set({
    color: document.querySelector("#entryCount").value
  });
}

function restoreOptions() {
  chrome.storage.local.get("entryCount", (res) => {
    document.querySelector("#entryCount").value = res.color || 10;
  });
}

document.addEventListener("DOMContentLoaded", restoreOptions);
document.querySelector("form").addEventListener("submit", saveOptions);
